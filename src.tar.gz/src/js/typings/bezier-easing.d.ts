declare function BezierEasing(x1, y1, x2, y2);
declare module 'bezier-easing' {
    export = BezierEasing
}