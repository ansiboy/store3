declare module 'carousel' {
    import c = require('core/carousel');
    export = c;
}

declare module 'chitu.mobile' {
    import * as cm from 'core/chitu.mobile';
    export = cm;
}

// declare module 'ui' {
//     import m = require('modules/core/ui');
//     export = m;
// }