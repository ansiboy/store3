declare module 'formValidator' {
    import formValidator = require('core/formValidator');
}