declare module 'carousel' {
    import c = require('core/carousel');
}
declare module 'chitu.mobile' {
    import * as cm from 'core/chitu.mobile';
}

